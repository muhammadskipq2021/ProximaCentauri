URL = "www.skipq.org"
URL_NameSpace="irfanhassanSkipQ_WebHealth_Monitor"
URL_Aailibilty = "URL_Aailibilty"
URL_Latency = "URL_Latency"
threshold = [0.31,0.34,0.50,0.23]
table_name = "Irfandynamodb_Table"
bucket = "irfanskipq"
file_name = "URLS.json"